import { Pool } from 'pg';
declare const pool: Pool;
export declare const testConnection: () => Promise<boolean>;
export default pool;
//# sourceMappingURL=database.d.ts.map