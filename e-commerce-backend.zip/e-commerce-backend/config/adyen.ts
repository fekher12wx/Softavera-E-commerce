import { Client, Config, CheckoutAPI } from '@adyen/api-library';

const config = new Config();
config.apiKey = process.env.ADYEN_API_KEY;
config.environment = process.env.ADYEN_ENVIRONMENT === 'LIVE' ? 'LIVE' : 'TEST';

const client = new Client({ config });
const checkout = new CheckoutAPI(client);

export { checkout };
