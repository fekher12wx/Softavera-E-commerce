import { Router } from 'express';
import paymentController from '../controllers/paymentController';

const router = Router();

// POST /api/payments/session
router.post('/session', paymentController.createCheckoutSession);

export default router; 