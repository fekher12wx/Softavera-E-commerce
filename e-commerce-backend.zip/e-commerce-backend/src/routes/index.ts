import { Router } from 'express';
import auth from './auth';
import products from './productRoute';
import users from './userRoute';
import orders from './orderRoute';
import payments from './paymentRoute';

const router = Router();

router.use('/products', products); 
router.use('/users',users); 
router.use('/orders',orders);
router.use('/auth', auth);
router.use('/payments', payments);

// Health check endpoint
router.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

export default router;