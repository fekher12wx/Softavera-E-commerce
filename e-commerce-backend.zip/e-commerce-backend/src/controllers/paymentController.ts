import { Request, Response } from 'express';
import { createCheckoutSession, getPaymentMethods } from '../adyen/adyen';

const paymentController = {
  async createCheckoutSession(req: Request, res: Response): Promise<void> {
    try {
      const { amount, currency, countryCode, reference, returnUrl, lineItems, store } = req.body;
      
      // Validate required fields
      if (!amount || !currency || !countryCode || !returnUrl) {
        res.status(400).json({ 
          error: 'Missing required fields: amount, currency, countryCode, returnUrl' 
        });
        return;
      }

      console.log('Creating checkout session with params:', {
        amount,
        currency,
        countryCode,
        reference,
        returnUrl,
        lineItems: lineItems?.length || 0,
        store
      });

      // Create the session
      const session = await createCheckoutSession({
        amount,
        currency,
        countryCode,
        reference,
        returnUrl,
        lineItems,
        store
      });

      const clientKey = process.env.ADYEN_CLIENT_KEY;
      if (!clientKey) {
        throw new Error('ADYEN_CLIENT_KEY is not set in environment variables');
      }

      // Don't pass paymentMethodsConfiguration to the session
      // The Drop-in will handle this automatically
      const response = { 
        session, 
        clientKey
      };

      console.log('Sending response:', JSON.stringify(response, null, 2));
      
      res.status(200).json(response);
    } catch (error) {
      console.error('Adyen session error:', error);
      const message = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ 
        error: 'Failed to create Adyen session', 
        details: message 
      });
    }
  },

  // Optional: Add a separate endpoint to test payment methods
  async getPaymentMethods(req: Request, res: Response): Promise<void> {
    try {
      const { amount, currency, countryCode } = req.body;
      
      if (!amount || !currency || !countryCode) {
        res.status(400).json({ 
          error: 'Missing required fields: amount, currency, countryCode' 
        });
        return;
      }

      const paymentMethods = await getPaymentMethods({
        amount,
        currency,
        countryCode
      });

      res.status(200).json(paymentMethods);
    } catch (error) {
      console.error('Payment methods error:', error);
      const message = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ 
        error: 'Failed to fetch payment methods', 
        details: message 
      });
    }
  }
};

export default paymentController;