import { v4 as uuidv4 } from 'uuid';
import { Client, Config, CheckoutAPI, Types } from '@adyen/api-library';

export async function createCheckoutSession({
  amount,
  currency,
  countryCode,
  reference,
  returnUrl,
  lineItems,
  store
}: {
  amount: number,
  currency: string,
  countryCode: string,
  reference?: string,
  returnUrl: string,
  lineItems?: Array<{ quantity: number; amountIncludingTax: number; description: string }>,
  store?: string
}) {
  const merchantAccount = process.env.ADYEN_MERCHANT_ACCOUNT;
  if (!merchantAccount) {
    throw new Error('ADYEN_MERCHANT_ACCOUNT is not set in environment variables');
  }
  if (!process.env.ADYEN_API_KEY) {
    throw new Error('ADYEN_API_KEY is not set in environment variables');
  }

  // Adyen NodeJS library configuration
  const config = new Config();
  config.apiKey = process.env.ADYEN_API_KEY;
  const client = new Client({ config });
  client.setEnvironment(process.env.ADYEN_ENVIRONMENT === 'LIVE' ? 'LIVE' : 'TEST');
  const checkout = new CheckoutAPI(client);

  const orderReference = reference || uuidv4();

  try {
    // Create session request - this should include payment methods automatically
    const sessionRequest: Types.checkout.CreateCheckoutSessionRequest = {
      reference: orderReference,
      amount: {
        currency,
        value: amount
      },
      merchantAccount,
      countryCode,
      returnUrl,
      // Add line items if provided
      ...(lineItems && lineItems.length > 0 ? { lineItems } : {}),
      // Add store if provided
      ...(store ? { store } : {}),
      // Specify channel
      channel: Types.checkout.CreateCheckoutSessionRequest.ChannelEnum.Web,
      shopperInteraction: Types.checkout.CreateCheckoutSessionRequest.ShopperInteractionEnum.Ecommerce // Use enum value
    };

    console.log('Creating session with request:', JSON.stringify(sessionRequest, null, 2));

    const session = await checkout.PaymentsApi.sessions(sessionRequest, { 
      idempotencyKey: uuidv4() 
    });
    
    console.log('Session created successfully:', JSON.stringify(session, null, 2));
    
    return session;
  } catch (err: any) {
    console.error(`Adyen session creation error: ${err.message}, error code: ${err.errorCode}`);
    console.error('Full error:', err);
    throw err;
  }
}

// Separate function to get payment methods (for debugging)
export async function getPaymentMethods({
  amount,
  currency,
  countryCode
}: {
  amount: number,
  currency: string,
  countryCode: string
}): Promise<Types.checkout.PaymentMethodsResponse> {
  const merchantAccount = process.env.ADYEN_MERCHANT_ACCOUNT;
  if (!merchantAccount) {
    throw new Error('ADYEN_MERCHANT_ACCOUNT is not set in environment variables');
  }
  if (!process.env.ADYEN_API_KEY) {
    throw new Error('ADYEN_API_KEY is not set in environment variables');
  }

  const config = new Config();
  config.apiKey = process.env.ADYEN_API_KEY;
  const client = new Client({ config });
  client.setEnvironment(process.env.ADYEN_ENVIRONMENT === 'LIVE' ? 'LIVE' : 'TEST');
  const checkout = new CheckoutAPI(client);

  try {
    const paymentMethodsRequest: Types.checkout.PaymentMethodsRequest = {
      merchantAccount,
      countryCode,
      amount: {
        currency,
        value: amount
      },
      channel: Types.checkout.PaymentMethodsRequest.ChannelEnum.Web
    };

    const paymentMethods = await checkout.PaymentsApi.paymentMethods(paymentMethodsRequest);
    console.log('Payment methods fetched:', JSON.stringify(paymentMethods, null, 2));
    return paymentMethods;
  } catch (err: any) {
    console.error(`Error fetching payment methods: ${err.message}, error code: ${err.errorCode}`);
    throw err;
  }
}