import { createClient } from 'redis';

const redisClient = createClient({
  url: process.env.REDIS_URL || 'redis://localhost:6379',
});

redisClient.on('error', (err) => {
  console.warn('Redis Client Error - Redis may not be running:', err.message);
  // Don't throw error, just log it
});

redisClient.on('connect', () => {
  console.log('✅ Redis Client Connected');
});

redisClient.on('ready', () => {
  console.log('✅ Redis Client Ready');
});

redisClient.on('end', () => {
  console.log('❌ Redis Client Disconnected');
});

// Wrap Redis operations to handle connection failures gracefully
const safeRedisOperation = async (operation: () => Promise<any>, fallback?: any) => {
  try {
    if (!redisClient.isOpen) {
      await redisClient.connect();
    }
    return await operation();
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.warn('Redis operation failed, using fallback:', errorMessage);
    return fallback;
  }
};

// Export wrapped Redis client with safe operations
export const safeRedis = {
  get: async (key: string) => {
    return safeRedisOperation(async () => await redisClient.get(key), null);
  },
  set: async (key: string, value: string, options?: any) => {
    return safeRedisOperation(async () => await redisClient.set(key, value, options), 'OK');
  },
  del: async (key: string) => {
    return safeRedisOperation(async () => await redisClient.del(key), 0);
  },
  exists: async (key: string) => {
    return safeRedisOperation(async () => await redisClient.exists(key), 0);
  },
  expire: async (key: string, seconds: number) => {
    return safeRedisOperation(async () => await redisClient.expire(key, seconds), 0);
  }
};

// Redis health check function
export const checkRedisHealth = async () => {
  try {
    if (!redisClient.isOpen) {
      await redisClient.connect();
    }
    await redisClient.ping();
    console.log('✅ Redis is healthy and responding');
    return true;
  } catch (error) {
    console.log('❌ Redis is not available, using fallback mode');
    return false;
  }
};

export default redisClient; 