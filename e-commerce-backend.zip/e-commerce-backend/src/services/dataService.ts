import pool from '../../config/database';
import { Product, User, Order, UserRole } from '../models';
import { v4 as uuidv4 } from 'uuid';
import bcrypt from 'bcryptjs';

export interface UserModel extends User {
  password: string;
  role: UserRole;
  createdAt: Date;
  updatedAt: Date;
}

export class DatabaseService {
  async updateProductImage(id: string, imageUrl: string): Promise<Product | null> {
    const now = new Date();
    const result = await pool.query(
      `UPDATE products SET image = $1, updated_at = $2 WHERE id = $3 RETURNING *`,
      [imageUrl, now, id]
    );
    return result.rows.length > 0 ? this.mapProductRow(result.rows[0]) : null;
  }
  
  // Auth-related User methods
  async createUserWithPassword(userData: {
    email: string;
    name: string;
    password: string;
    role?: UserRole;
    address?: {
      street: string;
      city: string;
      zipCode: string;
      country: string;
    };
  }): Promise<UserModel> {
    const id = uuidv4();
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    const now = new Date();
    
    const query = `
      INSERT INTO users (id, email, name, password, role, street, city, zip_code, country, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *
    `;
    const values = [
      id,
      userData.email,
      userData.name,
      hashedPassword,
      userData.role || UserRole.USER,
      userData.address?.street || null,
      userData.address?.city || null,
      userData.address?.zipCode || null,
      userData.address?.country || null,
      now,
      now
    ];
    
    const result = await pool.query(query, values);
    return this.mapUserModelRow(result.rows[0]);
  }

  async getUserByEmail(email: string): Promise<UserModel | null> {
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    return result.rows.length > 0 ? this.mapUserModelRow(result.rows[0]) : null;
  }

  async getUserModelById(id: string): Promise<UserModel | null> {
    const result = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
    return result.rows.length > 0 ? this.mapUserModelRow(result.rows[0]) : null;
  }

  async updateUserPassword(id: string, newPassword: string): Promise<boolean> {
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    const result = await pool.query(
      'UPDATE users SET password = $1, updated_at = $2 WHERE id = $3',
      [hashedPassword, new Date(), id]
    );
    return (result.rowCount ?? 0) > 0;
  }

  // Product methods
  async getAllProducts(): Promise<Product[]> {
    const result = await pool.query('SELECT * FROM products ORDER BY created_at DESC');
    return result.rows.map(this.mapProductRow);
  }

  // Get products by category
  async getProductsByCategory(category: string): Promise<Product[]> {
    const result = await pool.query(
      'SELECT * FROM products WHERE category ILIKE $1 ORDER BY created_at DESC',
      [`%${category}%`]
    );
    return result.rows.map(this.mapProductRow);
  }

  // Get products by category and subcategory
  async getProductsByCategoryAndSubcategory(category: string, subcategory: string): Promise<Product[]> {
    const result = await pool.query(
      'SELECT * FROM products WHERE category ILIKE $1 AND subcategory ILIKE $2 ORDER BY created_at DESC',
      [`%${category}%`, `%${subcategory}%`]
    );
    return result.rows.map(this.mapProductRow);
  }

  // NEW: Search products by name or description
  async searchProducts(searchTerm: string): Promise<Product[]> {
    const result = await pool.query(
      'SELECT * FROM products WHERE name ILIKE $1 OR description ILIKE $1 ORDER BY created_at DESC',
      [`%${searchTerm}%`]
    );
    return result.rows.map(this.mapProductRow);
  }

  // NEW: Get all available categories
  async getProductCategories(): Promise<string[]> {
    const result = await pool.query('SELECT DISTINCT category FROM products ORDER BY category');
    return result.rows.map(row => row.category);
  }

  async getProductById(id: string): Promise<Product | null> {
    const result = await pool.query('SELECT * FROM products WHERE id = $1', [id]);
    return result.rows.length > 0 ? this.mapProductRow(result.rows[0]) : null;
  }

  async createProduct(product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Promise<Product> {
    const id = uuidv4();
    const now = new Date();
    const query = `
      INSERT INTO products (id, name, price, description, category, subcategory, image, stock, rating, reviews, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *
    `;
    const values = [
      id,
      product.name,
      product.price,
      product.description,
      product.category,
      product.subcategory || null,
      product.image,
      product.stock,
      product.rating,
      product.reviews,
      now,
      now
    ];
    
    const result = await pool.query(query, values);
    return this.mapProductRow(result.rows[0]);
  }

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product | null> {
    const updateFields = { ...updates, updatedAt: new Date() };
    const setClause = Object.keys(updateFields)
      .map((key, index) => `${this.camelToSnake(key)} = $${index + 2}`)
      .join(', ');
    
    const values = [id, ...Object.values(updateFields)];
    const query = `UPDATE products SET ${setClause} WHERE id = $1 RETURNING *`;
    
    const result = await pool.query(query, values);
    return result.rows.length > 0 ? this.mapProductRow(result.rows[0]) : null;
  }

  async deleteProduct(id: string): Promise<boolean> {
    const result = await pool.query('DELETE FROM products WHERE id = $1', [id]);
    return (result.rowCount ?? 0) > 0;
  }

  // User methods (without password)
  async getAllUsers(): Promise<User[]> {
    const result = await pool.query('SELECT id, email, name, role, street, city, zip_code, country, created_at, updated_at FROM users ORDER BY created_at DESC');
    return result.rows.map(this.mapUserRow);
  }

  async getUserById(id: string): Promise<User | null> {
    const result = await pool.query('SELECT id, email, name, role, street, city, zip_code, country, created_at, updated_at FROM users WHERE id = $1', [id]);
    return result.rows.length > 0 ? this.mapUserRow(result.rows[0]) : null;
  }

  async createUser(user: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): Promise<User> {
    const id = uuidv4();
    const now = new Date();
    const query = `
      INSERT INTO users (id, email, name, role, street, city, zip_code, country, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING id, email, name, role, street, city, zip_code, country, created_at, updated_at
    `;
    const values = [
      id,
      user.email,
      user.name,
      user.role || UserRole.USER,
      user.address?.street || null,
      user.address?.city || null,
      user.address?.zipCode || null,
      user.address?.country || null,
      now,
      now
    ];
    
    const result = await pool.query(query, values);
    return this.mapUserRow(result.rows[0]);
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | null> {
    try {
      const { address, ...userUpdates } = updates;
      console.log('Updating user in database:', { id, updates, address });
      
      // Build the SET clause and values array
      const updateFields: any = { ...userUpdates };
      const values: any[] = [];
      const setClauses: string[] = [];
      let paramCount = 1;

      // Add address fields if present
      if (address) {
        updateFields.street = address.street;
        updateFields.city = address.city;
        updateFields.zip_code = address.zipCode;
        updateFields.country = address.country;
      }

      // Build the SET clause
      for (const [key, value] of Object.entries(updateFields)) {
        if (value !== undefined) {
          setClauses.push(`${this.camelToSnake(key)} = $${paramCount}`);
          values.push(value);
          paramCount++;
        }
      }

      // Add updated_at
      setClauses.push(`updated_at = $${paramCount}`);
      values.push(new Date());

      // Add id as the last parameter
      values.push(id);

      const query = `
        UPDATE users 
        SET ${setClauses.join(', ')} 
        WHERE id = $${paramCount + 1}
        RETURNING id, email, name, role, street, city, zip_code, country, created_at, updated_at
      `;

      console.log('Executing query:', query);
      console.log('With values:', values);

      const result = await pool.query(query, values);
      
      if (result.rows.length === 0) {
        console.log('No user found with ID:', id);
        return null;
      }

      const updatedUser = this.mapUserRow(result.rows[0]);
      console.log('Updated user:', updatedUser);
      return updatedUser;
    } catch (error) {
      console.error('Error updating user:', error);
      throw error;
    }
  }

  async deleteUser(id: string): Promise<boolean> {
    const result = await pool.query('DELETE FROM users WHERE id = $1', [id]);
    return (result.rowCount ?? 0) > 0;
  }

  // Order methods
  async getAllOrders(): Promise<Order[]> {
    const result = await pool.query(`
      SELECT o.*, 
             oi.id as item_id, oi.quantity, oi.price as item_price,
             p.id as product_id, p.name as product_name, p.description as product_description,
             p.category as product_category, p.image as product_image, p.stock as product_stock,
             p.rating as product_rating, p.reviews as product_reviews
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      LEFT JOIN products p ON oi.product_id = p.id
      ORDER BY o.created_at DESC
    `);
    
    return this.groupOrdersWithItems(result.rows);
  }

  async getOrderById(id: string): Promise<Order | null> {
    const result = await pool.query(`
      SELECT o.*, 
             oi.id as item_id, oi.quantity, oi.price as item_price,
             p.id as product_id, p.name as product_name, p.description as product_description,
             p.category as product_category, p.image as product_image, p.stock as product_stock,
             p.rating as product_rating, p.reviews as product_reviews
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      LEFT JOIN products p ON oi.product_id = p.id
      WHERE o.id = $1
    `, [id]);
    
    if (result.rows.length === 0) return null;
    return this.groupOrdersWithItems(result.rows)[0];
  }

  async getOrdersByUserId(userId: string): Promise<Order[]> {
    const result = await pool.query(`
      SELECT o.*, 
             oi.id as item_id, oi.quantity, oi.price as item_price,
             p.id as product_id, p.name as product_name, p.description as product_description,
             p.category as product_category, p.image as product_image, p.stock as product_stock,
             p.rating as product_rating, p.reviews as product_reviews
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      LEFT JOIN products p ON oi.product_id = p.id
      WHERE o.user_id = $1
      ORDER BY o.created_at DESC
    `, [userId]);
    
    return this.groupOrdersWithItems(result.rows);
  }

  async createOrder(order: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>): Promise<Order> {
    const client = await pool.connect();
    
    try {
      await client.query('BEGIN');
      
      const orderId = uuidv4();
      const now = new Date();
      
      // Insert order
      const orderQuery = `
        INSERT INTO orders (id, user_id, total, status, shipping_street, shipping_city, 
                           shipping_zip_code, shipping_country, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        RETURNING *
      `;
      const orderValues = [
        orderId,
        order.userId ?? null, // Insert NULL for guest orders
        order.total,
        order.status,
        order.shippingAddress.street,
        order.shippingAddress.city,
        order.shippingAddress.zipCode,
        order.shippingAddress.country,
        now,
        now
      ];
      
      const orderResult = await client.query(orderQuery, orderValues);
      
      // Insert order items
      for (const item of order.items) {
        // Defensive: ensure price is never null
        const price = item.product?.price;
        if (price === undefined) throw new Error(`Order item price is missing for product ${item.product?.id}`);
        const itemQuery = `
          INSERT INTO order_items (order_id, product_id, quantity, price)
          VALUES ($1, $2, $3, $4)
        `;
        await client.query(itemQuery, [orderId, item.product.id, item.quantity, price]);
        // Decrement product stock
        const updateStockQuery = `
          UPDATE products SET stock = stock - $1 WHERE id = $2
        `;
        await client.query(updateStockQuery, [item.quantity, item.product.id]);
      }
      
      await client.query('COMMIT');
      
      // Return the created order with items
      return await this.getOrderById(orderId) as Order;
      
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async updateOrderStatus(id: string, status: Order['status']): Promise<Order | null> {
    const result = await pool.query(
      'UPDATE orders SET status = $1, updated_at = $2 WHERE id = $3 RETURNING *',
      [status, new Date(), id]
    );
    
    if (result.rows.length === 0) return null;
    return await this.getOrderById(id);
  }

  async updateOrder(id: string, updates: Partial<Order>): Promise<Order | null> {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      // Build dynamic SET clause
      const setClauses: string[] = [];
      const values: any[] = [];
      let paramCount = 1;

      if (updates.total !== undefined) {
        setClauses.push(`total = $${paramCount++}`);
        values.push(updates.total);
      }
      if (updates.status !== undefined) {
        setClauses.push(`status = $${paramCount++}`);
        values.push(updates.status);
      }
      if (updates.shippingAddress) {
        if (updates.shippingAddress.street !== undefined) {
          setClauses.push(`shipping_street = $${paramCount++}`);
          values.push(updates.shippingAddress.street);
        }
        if (updates.shippingAddress.city !== undefined) {
          setClauses.push(`shipping_city = $${paramCount++}`);
          values.push(updates.shippingAddress.city);
        }
        if (updates.shippingAddress.zipCode !== undefined) {
          setClauses.push(`shipping_zip_code = $${paramCount++}`);
          values.push(updates.shippingAddress.zipCode);
        }
        if (updates.shippingAddress.country !== undefined) {
          setClauses.push(`shipping_country = $${paramCount++}`);
          values.push(updates.shippingAddress.country);
        }
      }
      setClauses.push(`updated_at = $${paramCount++}`);
      values.push(new Date());
      values.push(id);

      const query = `
        UPDATE orders
        SET ${setClauses.join(', ')}
        WHERE id = $${paramCount}
        RETURNING *
      `;
      await client.query(query, values);

      // Optionally update order items if provided
      if (updates.items) {
        await client.query('DELETE FROM order_items WHERE order_id = $1', [id]);
        for (const item of updates.items) {
          await client.query(
            'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($1, $2, $3, $4)',
            [id, item.product.id, item.quantity, item.product.price]
          );
        }
      }
      await client.query('COMMIT');
      return await this.getOrderById(id);
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async deleteOrder(id: string): Promise<boolean> {
    const result = await pool.query('DELETE FROM orders WHERE id = $1', [id]);
    return (result.rowCount ?? 0) > 0;
  }

  // Helper methods
  private mapProductRow(row: any): Product {
    return {
      id: row.id,
      name: row.name,
      price: parseFloat(row.price),
      description: row.description,
      category: row.category,
      subcategory: row.subcategory,
      image: row.image,
      stock: row.stock,
      rating: parseFloat(row.rating),
      reviews: row.reviews,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }

  private mapUserRow(row: any): User {
    const user: User = {
      id: row.id,
      email: row.email,
      name: row.name,
      role: row.role,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };

    if (row.street || row.city || row.zip_code || row.country) {
      user.address = {
        street: row.street || '',
        city: row.city || '',
        zipCode: row.zip_code || '',
        country: row.country || ''
      };
    }

    return user;
  }

  private mapUserModelRow(row: any): UserModel {
    const user: UserModel = {
      id: row.id,
      email: row.email,
      name: row.name,
      password: row.password,
      role: row.role,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };

    if (row.street || row.city || row.zip_code || row.country) {
      user.address = {
        street: row.street || '',
        city: row.city || '',
        zipCode: row.zip_code || '',
        country: row.country || ''
      };
    }

    return user;
  }

  private groupOrdersWithItems(rows: any[]): Order[] {
    const ordersMap = new Map<string, Order>();

    for (const row of rows) {
      if (!ordersMap.has(row.id)) {
        ordersMap.set(row.id, {
          id: row.id,
          userId: row.user_id,
          items: [],
          total: parseFloat(row.total),
          status: row.status,
          createdAt: row.created_at,
          updatedAt: row.updated_at,
          shippingAddress: {
            street: row.shipping_street,
            city: row.shipping_city,
            zipCode: row.shipping_zip_code,
            country: row.shipping_country
          }
        });
      }

      if (row.item_id) {
        const order = ordersMap.get(row.id)!;
        order.items.push({
          product: {
            id: row.product_id,
            name: row.product_name,
            price: parseFloat(row.item_price),
            description: row.product_description,
            category: row.product_category,
            image: row.product_image,
            stock: row.product_stock,
            rating: parseFloat(row.product_rating),
            reviews: row.product_reviews
          },
          quantity: row.quantity
        });
      }
    }

    return Array.from(ordersMap.values());
  }

  private camelToSnake(str: string): string {
    return str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
  }
}

export default new DatabaseService();