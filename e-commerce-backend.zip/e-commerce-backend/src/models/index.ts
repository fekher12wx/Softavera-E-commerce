// User roles
export enum UserRole {
  USER = 'user',
  ADMIN = 'admin'
}

// Address interface
export interface Address {
  street: string;
  city: string;
  zipCode: string;
  country: string;
}

// Product interface
export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  category: string;
  subcategory?: string;
  image: string;
  stock: number;
  rating: number;
  reviews: number;
  createdAt?: Date;
  updatedAt?: Date;
}

// User interface (without password)
export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  address?: Address;
  createdAt?: Date;
  updatedAt?: Date;
}

// Cart item interface
export interface CartItem {
  product: Product;
  quantity: number;
}

// Order interface
export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  shippingAddress: Address;
  createdAt: Date;
  updatedAt?: Date;
}

// Auth-related types
export interface AuthUser extends User {
  password?: never; // Never expose password in frontend
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  email: string;
  password: string;
  name: string;
  address?: Address;
}

export interface AuthResponse {
  user: AuthUser;
  token: string;
  refreshToken: string;
}

export interface AuthContextType {
  user: AuthUser | null;
  login: (credentials: LoginCredentials) => Promise<void>;
  register: (credentials: RegisterCredentials) => Promise<void>;
  logout: () => void;
  loading: boolean;
  isAuthenticated: boolean;
  isAdmin: boolean;
}

// Order status type
export type OrderStatus = Order['status'];

// CRUD operation types
export type CreateProduct = Omit<Product, 'id' | 'createdAt' | 'updatedAt'>;
export type UpdateProduct = Partial<CreateProduct>;

export type CreateUser = Omit<User, 'id' | 'createdAt' | 'updatedAt'>;
export type UpdateUser = Partial<CreateUser>;

export type CreateOrder = Omit<Order, 'id' | 'createdAt' | 'updatedAt'>;
export type UpdateOrder = Partial<CreateOrder>;

// Request/Response types
export interface ChangePasswordRequest {
  currentPassword: string;
  newPassword: string;
}

export interface UpdateProfileRequest {
  name?: string;
  address?: Address;
}